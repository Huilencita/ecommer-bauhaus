let listOfProducts = [{
    "id" : 1,
    "img": "bauhaus-building.png",
    "name" : "Bauhaus Building",
    "description" : "Michael Kimmerle gives an introduction to the world of the Bauhaus.",
    "price" : 1200,
}, {
    "id" : 2,
    "img": "bauhaus-1.png",
    "name" : "Bauhaus Exhibition 1923",
    "description" : "Herbert Bayer Poster Bauhaus Exhibition Weimar July - Sept 1923",
    "price" : 2000,
},{
    "id" : 3,
    "img": "bauhaus-staircase.png",
    "name" : "Bauhaus Staircase",
    "description" : "Iconic Stairs in the Bauhaus building in Dessau Germany by Walter Gropius",
    "price" : 1780,
}, {
    "id" : 4,
    "img": "poster-bauhaus-tel-aviv-00.jpg",
    "name" : "Bauhaus Tel Aviv",
    "description" : "Tel Aviv is the unique world capital of Bauhaus buildings.",
    "price" : 1050,
}, {
    "id" : 5,
    "img": "poster-bauhaus-tel-aviv-v2-00.jpg",
    "name" : "Bauhaus Tel Aviv Building",
    "description" : "Tel Aviv is the unique world capital of Bauhaus buildings.",
    "price" : 1050,
}
] 

