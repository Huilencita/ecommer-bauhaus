//declaro variables
const bodyContent = document.getElementById("cart-container");
//variable del ciclo en el body
const cardProduct = document.getElementById("card-product");
// variable para agregar al carrito
const cardBtn = document.getElementById("card-btn");
//variable que reemplaza lo qeu esta en el carrito
let totalCard = document.getElementById("total-product");
//variable que agrega cada producto en el carrito
let totalCardDescription = document.getElementById("selected-products");

function showProducts(listOfProducts){
    bodyContent.innerHTML = "";
    listOfProducts.forEach(function(product){
        const card = buildProduct(product);
        bodyContent.innerHTML += card;
    });
}
function buildProduct(product) {
    let aux = `
        <div id="card-product">
            <img src="/cromier/asset/bauhaus-shop/${product.img}" alt="">
            <div>
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <h2>${product.price}</h2>   
            </div>
            <button id="card-btn" onclick="total()" type="submit" value="${product.price}">Agregar al Carrito</button>
        </div>
        `;
    console.log(product)
    return aux;
    }
showProducts(listOfProducts);

//funcion para sumar el total

function total (){
    all = 0;
    listOfProducts.forEach(product => {
        all += product.price
    })
    return all;
}

total();



function totalHtml (){
    let text = `
        <div id="total-product">
            <h4>TOTAL</h4>
            <div id="selected-products">
                <h5>Nombre :</h5>
                <h5>Cantidad :</h5>
            </div>
            <h3>Precio total:${total}</h5>
            <button id="card-btn" type="submit">Iniciar compra</button>
        </div>
    `
    return text;
}
totalHtml()







